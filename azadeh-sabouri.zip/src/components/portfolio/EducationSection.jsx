import React from 'react';
import { motion } from 'framer-motion';
import { GraduationCap, Award } from 'lucide-react';

const EDUCATION = [
  {
    title: 'Laurea Specialistica (Master), Industrial Design',
    institution: 'Politecnico di Milano',
    year: '2008 – 2012',
    description: 'Learned how to cope with complex systems of products and services, and capability of strategic vision. Skills in engineering and an understanding of the technological aspects and the planning, to the definition of the project in strategic and administrative terms.',
  },
  {
    title: 'System Organisation and Industrialisation of Services, Innovation and Design Thinking',
    institution: 'Ålborg Universitet',
    year: '2014',
    description: 'Using Design Thinking in accelerating innovation to help create better solutions for the challenges facing modern businesses. Learning how to use design thinking creative methods and tools to be a successful innovator — to divine the future and deliver solutions that confer competitive advantage.',
  },
];

const CERTIFICATES = [
  {
    title: 'Artificial Intelligence (AI): Implication for Business Strategy',
    issuer: 'MIT Sloan School of Management',
    year: 'Jan 2020',
  },
  {
    title: 'UX Management: Strategy and Tactics',
    issuer: 'IxDF — The Interaction Design Foundation',
    year: 'May 2018',
  },
  {
    title: 'Advanced Google Analytics',
    issuer: 'Google Analytics',
    year: 'Oct 2021',
  },
  {
    title: 'Conducting Usability Testing',
    issuer: 'IxDF — The Interaction Design Foundation',
    year: 'Apr 2018',
  },
];

export default function EducationSection() {
  return (
    <section id="education" className="py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <span className="mono-label text-muted-foreground mb-4 block">Background</span>
        <h2 className="text-3xl lg:text-4xl font-semibold tracking-tight mb-12 max-w-2xl">
          Education & Certifications
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Education */}
          <div>
            <div className="flex items-center gap-2 mb-6">
              <GraduationCap className="w-4 h-4 text-primary/60" />
              <span className="mono-label text-muted-foreground">Education</span>
            </div>
            <div className="space-y-4">
              {EDUCATION.map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.1 }}
                  className="p-5 rounded-xl border border-border/50 bg-secondary/10 hover:border-primary/20 transition-colors"
                >
                  <div className="flex items-start justify-between gap-4 mb-1">
                    <h3 className="font-semibold text-foreground text-sm leading-snug">{item.title}</h3>
                    <span className="font-mono text-xs text-muted-foreground flex-shrink-0">{item.year}</span>
                  </div>
                  <p className="text-xs text-primary/70 mb-2">{item.institution}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed">{item.description}</p>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Certificates */}
          <div>
            <div className="flex items-center gap-2 mb-6">
              <Award className="w-4 h-4 text-primary/60" />
              <span className="mono-label text-muted-foreground">Certifications</span>
            </div>
            <div className="space-y-3">
              {CERTIFICATES.map((cert, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.08 }}
                  className="flex items-center justify-between gap-4 p-4 rounded-xl border border-border/50 bg-secondary/10 hover:border-primary/20 transition-colors"
                >
                  <div>
                    <p className="text-sm font-medium text-foreground">{cert.title}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{cert.issuer}</p>
                  </div>
                  <span className="font-mono text-xs text-muted-foreground flex-shrink-0">{cert.year}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
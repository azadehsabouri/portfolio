import React from 'react';
import MetricCard from './MetricCard';

const METRICS = [
{
  prefix: '',
  value: '5,000+',
  suffix: ' customer insights consolidated into one searchable knowledge system'
},
{
  prefix: '',
  value: '500+',
  suffix: ' internal users adopted insights to drive product and strategy decisions'
},
{
  prefix: '',
  value: '33+',
  suffix: ' customer touchpoints measured across the complete journey'
},
{
  prefix: '',
  value: '3.5 → 4.7',
  suffix: 'Service CSAT raised through systematic experience improvement'
},
{
  prefix: '',
  value: '10+',
  suffix: ' software features shipped within one year, grounded in customer evidence'
},
{
  prefix: '',
  value: 'UX Multiplier',
  suffix: 'Model built to quantify how experience improvements drive repurchase'
}];


export default function ImpactDashboard() {
  return (
    <section id="impact" className="py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div>
          <span className="mono-label text-muted-foreground mb-4 block">Metrics & Business Impact</span>
          <h2 className="text-3xl lg:text-4xl font-semibold tracking-tight-header mb-12 max-w-2xl">
            Quantified outcomes that connect customer understanding to business performance
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {METRICS.map((metric, i) =>
            <MetricCard key={i} {...metric} index={i} />
            )}
          </div>
        </div>
      </div>
    </section>);

}
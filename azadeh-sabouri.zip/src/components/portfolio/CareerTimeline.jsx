import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';

const CAREER = [
  {
    year: '2014',
    company: 'Dipa & Kvinfo',
    role: 'Freelance Designer',
    location: 'Copenhagen & London',
    duration: '1 yr',
    color: 'bg-muted-foreground/20',
  },
  {
    year: '2015',
    company: 'Eywasystems',
    role: 'UX & UI Designer',
    location: 'Copenhagen',
    duration: '1 yr',
    color: 'bg-muted-foreground/20',
  },
  {
    year: '2016',
    company: 'Aalborg University',
    role: 'Research Assistant',
    location: 'Copenhagen',
    duration: '6 mo',
    color: 'bg-muted-foreground/20',
  },
  {
    year: '2016',
    company: 'Tivoli',
    role: 'Experience Designer',
    location: 'Copenhagen',
    duration: '6 mo',
    color: 'bg-muted-foreground/20',
  },
  {
    year: '2016',
    company: 'Universal Robots',
    role: 'UX Designer',
    location: 'Odense',
    duration: '2016–2018',
    color: 'bg-primary/15',
    ur: true,
  },
  {
    year: '2018',
    company: 'Universal Robots',
    role: 'Senior UX Designer',
    location: 'Innovation Lab',
    duration: '2018–2021',
    color: 'bg-primary/25',
    ur: true,
  },
  {
    year: '2021',
    company: 'Universal Robots',
    role: 'Lead UX Research & Customer Insights',
    location: 'Product & UX',
    duration: '2021–2026',
    color: 'bg-primary/40',
    ur: true,
    current: true,
  },
];

export default function CareerTimeline() {
  const [active, setActive] = useState(CAREER.length - 1);
  const scrollRef = useRef(null);

  return (
    <section id="career" className="py-16 lg:py-24 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <span className="mono-label text-muted-foreground mb-4 block">Career Journey</span>
        <h2 className="text-3xl lg:text-4xl font-semibold tracking-tight mb-14 max-w-2xl">
          10+ Years of Experience
        </h2>

        {/* Scrollable timeline */}
        <div ref={scrollRef} className="overflow-x-auto pb-4 -mx-2 px-2">
          <div className="min-w-[700px]">


            {/* Year labels */}
            <div className="flex items-end mb-2 pl-0" style={{ gap: 0 }}>
              {CAREER.map((item, i) => (
                <div key={i} className="flex-1 text-center">
                  <span className="font-mono text-[10px] text-muted-foreground">{item.year} →</span>
                </div>
              ))}
            </div>


            {/* Track + nodes */}
            <div className="relative flex items-center" style={{ height: '56px' }}>
              {/* Connecting line */}
              <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-px bg-border" />

              {CAREER.map((item, i) => (
                <div key={i} className="flex-1 flex justify-center relative z-10">
                  <motion.button
                    initial={{ opacity: 0, scale: 0.5 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: i * 0.07 }}
                    onClick={() => setActive(active === i ? null : i)}
                    className={`relative flex items-center justify-center rounded-full border-2 transition-all duration-200 focus:outline-none
                      ${item.current
                        ? 'w-5 h-5 border-primary bg-primary shadow-md shadow-primary/30'
                        : item.ur
                          ? 'w-4 h-4 border-primary/60 bg-primary/20 hover:border-primary hover:bg-primary/40'
                          : 'w-3.5 h-3.5 border-border bg-background hover:border-primary/50 hover:bg-secondary'
                      }
                      ${active === i ? 'ring-2 ring-primary/30 ring-offset-2' : ''}
                    `}
                    aria-label={item.company}
                  >
                    {item.current && (
                      <span className="absolute inset-0 rounded-full animate-ping bg-primary/30" />
                    )}
                  </motion.button>
                </div>
              ))}
            </div>

            {/* Company labels below */}
            <div className="flex items-start mt-3">
              {CAREER.map((item, i) => (
                <div key={i} className="flex-1 flex flex-col items-center text-center px-1">
                  <span className={`text-[10px] font-medium leading-tight ${item.ur ? 'text-primary' : 'text-muted-foreground'}`}>
                    {item.ur ? 'Universal Robots' : item.company}
                  </span>
                  {item.ur && (
                    <span className="text-[9px] text-primary/60 mt-0.5 leading-tight">{item.role}</span>
                  )}
                  <span className="text-[9px] text-muted-foreground/60 mt-0.5 leading-tight">{item.duration}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Detail card */}
        <div className="mt-8 min-h-[80px]">
          {active !== null && (
            <motion.div
              key={active}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="p-5 rounded-xl border border-border/60 bg-secondary/20 max-w-lg"
            >
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className={`font-semibold text-sm ${CAREER[active].ur ? 'text-primary' : 'text-foreground'}`}>
                    {CAREER[active].company}
                  </p>
                  <p className="text-sm text-foreground mt-0.5">{CAREER[active].role}</p>
                  <p className="text-xs text-muted-foreground mt-1">{CAREER[active].location} · {CAREER[active].duration}</p>
                </div>
                {CAREER[active].current && (
                  <span className="text-[10px] font-mono bg-primary/10 text-primary px-2 py-1 rounded-full border border-primary/20">
                    Current
                  </span>
                )}
              </div>
            </motion.div>
          )}

        </div>
      </div>
    </section>
  );
}
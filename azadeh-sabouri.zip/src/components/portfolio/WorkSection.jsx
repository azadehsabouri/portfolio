import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';
import { CASE_STUDIES } from '@/components/caseStudy/caseStudyData';
import CaseStudyModal from '@/components/caseStudy/CaseStudyModal';

const STUDY_TABS = {
  'polaris': ['Customer Journey', 'Behavioral Archetypes', 'Industry Report'],
  'cx-measurement': ['UX Multiplier'],
  'product-foundations': ['AI-Empowered Field Visit Tool'],
};

export default function WorkSection() {
  const [openIndex, setOpenIndex] = useState(null);
  const [initialTab, setInitialTab] = useState(null);

  const openStudy = (i, tab = null) => { setOpenIndex(i); setInitialTab(tab); };
  const closeStudy = () => { setOpenIndex(null); setInitialTab(null); };
  const prevStudy = () => { setOpenIndex((i) => (i - 1 + CASE_STUDIES.length) % CASE_STUDIES.length); setInitialTab(null); };
  const nextStudy = () => { setOpenIndex((i) => (i + 1) % CASE_STUDIES.length); setInitialTab(null); };

  return (
    <section id="work" className="py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div>
          <span className="mono-label text-muted-foreground mb-4 block">What I've Built</span>
          <h2 className="text-3xl lg:text-4xl font-semibold tracking-tight-header mb-12 max-w-2xl">
            Scalable systems that connect customer understanding to measurable outcomes
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {CASE_STUDIES.map((study, i) =>
            <motion.div
              key={study.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className={`group cursor-pointer rounded-xl overflow-hidden border border-border/50 hover:border-primary/25 transition-all duration-300 ${i === 0 ? 'md:col-span-2' : ''}`}
              onClick={() => openStudy(i)}
            >
              
                {/* Image */}
                <div className={`relative w-full overflow-hidden ${study.heroImageFit === 'contain' ? 'bg-white' : 'bg-secondary/20'} ${i === 0 ? 'aspect-[16/7] md:aspect-[21/8]' : 'aspect-[4/3]'}`}>
                  <img src={study.heroImage} alt=""
                aria-hidden="true"
                className={`absolute inset-0 w-full h-full opacity-80 ${study.heroImageFit === 'contain' ? 'object-contain p-4' : 'object-cover group-hover:scale-[1.02]'} transition-transform duration-500`} />
                
                
                </div>

                {/* Card body */}
                <div className="p-6 lg:p-7">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <span className="mono-label text-primary/60 mb-2 block">{study.subtitle}</span>
                      <h3 className={`font-semibold tracking-tight-header leading-tight mb-2 ${i === 0 ? 'text-xl lg:text-2xl' : 'text-lg'}`}>
                        {study.titleFull}
                      </h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">{study.summary}</p>
                    </div>
                    <div className="w-9 h-9 flex-shrink-0 flex items-center justify-center rounded-lg border border-border/50 group-hover:border-primary/30 group-hover:bg-primary/5 transition-all">
                      <ArrowUpRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                    </div>
                  </div>

                  {/* Mini metrics */}
                  <div className="flex flex-wrap gap-2 mt-5">
                    {study.metrics.slice(0, 3).map((m) =>
                  <div key={m.label} className="flex items-center gap-1.5 px-3 py-1.5 bg-secondary/40 rounded-lg">
                        <span className="font-mono text-xs font-semibold text-foreground">{m.value}</span>
                        <span className="text-[10px] text-muted-foreground">{m.label}</span>
                      </div>
                  )}
                    <div className="flex items-center px-3 py-1.5 border border-primary/15 rounded-lg text-xs text-primary/70 font-medium gap-1">
                      View details <ArrowUpRight className="w-3 h-3" />
                    </div>
                  </div>

                  {/* Sub-tab indicators */}
                  {STUDY_TABS[study.id] && (
                    <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-border/40">
                      <span className="mono-label text-muted-foreground/50 self-center mr-1">Inside</span>
                      {STUDY_TABS[study.id].map((tab) => (
                        <button
                          key={tab}
                          onClick={(e) => { e.stopPropagation(); openStudy(i, tab); }}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-medium rounded-lg bg-background border border-border/60 text-foreground/60 tracking-wide hover:bg-primary/5 hover:text-primary/80 hover:border-primary/25 transition-all cursor-pointer shadow-sm">
                          <span className="w-1.5 h-1.5 rounded-full bg-primary/30 flex-shrink-0" />
                          {tab}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>

      {/* Modal */}
      <AnimatePresence>
        {openIndex !== null &&
        <CaseStudyModal
          study={CASE_STUDIES[openIndex]}
          onClose={closeStudy}
          onPrev={prevStudy}
          onNext={nextStudy}
          initialTab={initialTab} />

        }
      </AnimatePresence>
    </section>);

}
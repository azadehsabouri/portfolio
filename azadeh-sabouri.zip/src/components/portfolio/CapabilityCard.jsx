import React from 'react';
import { motion } from 'framer-motion';

export default function CapabilityCard({ icon: Icon, title, items, index = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="border border-border/50 rounded-xl p-6 lg:p-8 hover:border-primary/20 transition-colors"
    >
      <div className="w-10 h-10 rounded-lg bg-primary/5 flex items-center justify-center mb-5">
        <Icon className="w-5 h-5 text-primary" />
      </div>
      <h3 className="text-lg font-semibold tracking-tight-header mb-4">{title}</h3>
      <ul className="space-y-2.5">
        {items.map((item, i) => (
          <li key={i} className="text-sm text-muted-foreground leading-relaxed flex gap-2">
            <span className="w-1 h-1 rounded-full bg-primary/30 mt-2 flex-shrink-0" />
            {item}
          </li>
        ))}
      </ul>
    </motion.div>
  );
}
import React from 'react';
import { motion } from 'framer-motion';

const PRINCIPLES = [
{
  title: 'Reduce uncertainty',
  body: 'Replace assumptions with evidence. Build systems that make customer knowledge accessible, actionable, and continuous.'
},
{
  title: 'Connect insights to decisions',
  body: 'Research has value only when it reaches the people making decisions. Bridge the gap between understanding and execution.'
},
{
  title: 'Balance strategy and execution',
  body: 'Good strategy without operational rigor stays theoretical. Strong execution without strategic clarity wastes resources.'
},
{
  title: 'Build systems, not isolated studies',
  body: 'Scalable insight infrastructure compounds over time. One-off research loses value. Repeatable systems create lasting organizational capability.'
}];


export default function PhilosophySection() {
  return (
    <section id="philosophy" className="py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div>
          <span className="mono-label text-muted-foreground mb-4 block">Approach</span>
          <h2 className="text-3xl lg:text-4xl font-semibold tracking-tight-header mb-16 max-w-2xl">Principles that shape how I work

          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-border/50 rounded-xl overflow-hidden border border-border/50">
            {PRINCIPLES.map((p, i) =>
            <motion.div
              key={p.title}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="bg-background p-8 lg:p-10">
              
                <span className="font-mono text-xs text-primary/50 mb-4 block">
                  {String(i + 1).padStart(2, '0')}
                </span>
                <h3 className="text-lg font-semibold tracking-tight-header mb-3">
                  {p.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {p.body}
                </p>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </section>);

}
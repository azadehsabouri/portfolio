import React from 'react';
import { motion } from 'framer-motion';
import { Linkedin, Mail, MapPin, ArrowUpRight } from 'lucide-react';

export default function ContactSection() {
  return (
    <section id="contact" className="py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            <div className="lg:col-span-6">
              <span className="mono-label text-muted-foreground mb-4 block">Contact</span>
              <h2 className="text-3xl lg:text-4xl font-semibold tracking-tight-header mb-4">
                Let's connect
              </h2>
              <p className="text-muted-foreground leading-relaxed max-w-md">
                Open to conversations about product strategy, customer insights leadership,
                AI innovation, and senior strategic roles. Available for case study walkthroughs upon request.
              </p>
            </div>

            <div className="lg:col-span-6 flex flex-col gap-3 lg:pt-16">
              <motion.a
                href="https://www.linkedin.com/in/azadehsabouri"
                target="_blank"
                rel="noopener noreferrer"
                initial={{ opacity: 0, x: -10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4 }}
                className="flex items-center justify-between p-5 rounded-xl border border-border/50 hover:border-primary/30 hover:bg-primary/[0.02] transition-all group min-h-[44px]">
                
                <div className="flex items-center gap-4">
                  <Linkedin className="w-5 h-5 text-primary/60" />
                  <div>
                    <div className="text-sm font-medium">LinkedIn</div>
                    <div className="text-xs text-muted-foreground">Professional profile</div>
                  </div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
              </motion.a>

              <motion.a
                href="mailto:azadeh.sabouri@gmail.com"
                initial={{ opacity: 0, x: -10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.04 }}
                className="flex items-center justify-between p-5 rounded-xl border border-border/50 hover:border-primary/30 hover:bg-primary/[0.02] transition-all group min-h-[44px]">
                
                <div className="flex items-center gap-4">
                  <Mail className="w-5 h-5 text-primary/60" />
                  <div>
                    <div className="text-sm font-medium">Email</div>
                    <div className="text-xs text-muted-foreground">azadeh.sabouri@gmail.com</div>
                  </div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
              </motion.a>

              <motion.div
                initial={{ opacity: 0, x: -10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.08 }}
                className="flex items-center gap-4 p-5 rounded-xl border border-border/50">
                <MapPin className="w-5 h-5 text-primary/60" />
                <div>
                  <div className="text-sm font-medium">Location</div>
                  <div className="text-xs text-muted-foreground">Odense, Denmark</div>
                </div>
              </motion.div>


            </div>
          </div>
        </div>
      </div>
    </section>);

}
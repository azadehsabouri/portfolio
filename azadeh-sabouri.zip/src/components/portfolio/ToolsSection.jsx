import React from 'react';
import { motion } from 'framer-motion';

const TOOL_GROUPS = [
{
  label: 'Research & Insight',
  tools: ['UserTesting', 'UserZoom', 'EnjoyHQ', 'SurveyMonkey', 'SurveyXact', 'Hotjar', 'Google Analytics', 'Power BI', 'UXPressia']
},
{
  label: 'Product & Collaboration',
  tools: ['Jira', 'Confluence', 'Asana', 'SharePoint', 'Microsoft Teams', 'PowerPoint']
},
{
  label: 'Design & Prototyping',
  tools: ['Figma', 'Sketch', 'Adobe Illustrator', 'Adobe Photoshop', 'Adobe InDesign']
},
{
  label: 'AI & Productivity',
  tools: ['OpenAI Tools', 'Microsoft Copilot', 'Claude']
},
{
  label: 'Working Methods',
  tools: ['Agile', 'Lean', 'Kanban', 'Design Thinking', 'Double Diamond']
}];


export default function ToolsSection() {
  return (
    <section id="tools" className="py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            <div className="lg:col-span-4">
              <span className="mono-label text-muted-foreground mb-4 block">Tools & Methods</span>

            </div>

            <div className="lg:col-span-8 space-y-8">
              {TOOL_GROUPS.map((group, gi) =>
              <motion.div
                key={group.label}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: gi * 0.08 }}>
                
                  <span className="mono-label text-primary/60 mb-3 block">{group.label}</span>
                  <div className="flex flex-wrap gap-2">
                    {group.tools.map((tool) =>
                  <span
                    key={tool}
                    className="inline-flex items-center px-3.5 py-2 text-sm border border-border/70 rounded-lg text-foreground/80 bg-secondary/20 hover:border-primary/20 transition-colors">
                    
                        {tool}
                      </span>
                  )}
                  </div>
                </motion.div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>);

}
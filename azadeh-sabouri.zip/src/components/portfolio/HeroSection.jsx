import React from 'react';
import { motion } from 'framer-motion';
import { ArrowDown } from 'lucide-react';

const HERO_IMAGE = 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/4cebc2323_generated_71631eb9.png';

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center">
      <div className="max-w-7xl mx-auto px-6 lg:px-12 w-full pt-24 pb-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left — Positioning */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}>
            
            <span className="mono-label text-muted-foreground mb-6 block">
              Product Strategy · Customer Insights · AI Innovation
            </span>
            <h1 className="sm:text-5xl lg:text-6xl font-semibold tracking-tight-header leading-[1.08] text-foreground mb-6 text-xl">Customer experience and product development

            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed max-w-xl">I Building products and customer experiences that people want to use and organizations can scale with confidence, grounded in customer insights.


            </p>

            <div className="flex items-center gap-6 mt-10">
              <a
                href="#work"
                className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground text-sm font-medium rounded-lg hover:opacity-90 transition-opacity min-h-[44px]">
                
                Explore My Work
              </a>
              <a
                href="#contact"
                className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors min-h-[44px]">
                
                Get in Touch
              </a>
            </div>
          </motion.div>

          {/* Right — Abstract Visual */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className="relative hidden lg:flex justify-center"
            aria-hidden="true">
            
            <div className="relative w-full max-w-md aspect-[3/4] rounded-2xl overflow-hidden">
              <img src="https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/72108c187_Azadeh_Sabouri.png"

              alt=""
              className="w-full h-full object-cover" />
              
              <div className="absolute inset-0 bg-gradient-to-t from-background/20 to-transparent" />
            </div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 hidden lg:flex flex-col items-center gap-2">
          
          <span className="mono-label text-muted-foreground/50">Scroll</span>
          <ArrowDown className="w-4 h-4 text-muted-foreground/40 animate-bounce" />
        </motion.div>
      </div>
    </section>);

}
import React from 'react';

export default function Footer() {
  return (
    <footer className="py-12 border-t hairline">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <span className="mono-label text-muted-foreground/60">
            © {new Date().getFullYear()} Portfolio
          </span>
          <span className="text-xs text-muted-foreground/40">
            Strategy · Insights · Impact
          </span>
        </div>
      </div>
    </footer>
  );
}
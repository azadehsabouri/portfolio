import React from 'react';
import { motion } from 'framer-motion';

export default function MetricCard({ prefix = '', value, suffix = '', index = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.08 }}
      className="relative rounded-xl overflow-hidden px-5 py-5 flex flex-col justify-between min-h-[140px] bg-primary"
      aria-label={`${prefix}${value}${suffix}`}
    >
      {/* Metric value */}
      <div>
        <div className="font-sans text-3xl lg:text-4xl font-bold tracking-tight leading-none mb-3 text-primary-foreground">
          {value}
        </div>
        <p className="text-xs lg:text-sm text-primary-foreground/70 leading-snug font-normal">
          {suffix.trim()}
        </p>
      </div>

      {/* Bottom-left accent dot */}
      <div className="absolute top-4 right-4 w-2 h-2 rounded-full bg-primary-foreground/30" />
    </motion.div>
  );
}
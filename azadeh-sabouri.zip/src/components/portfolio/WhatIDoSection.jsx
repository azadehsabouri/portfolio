import React from 'react';
import { Target, Layers, Settings, BarChart3, Lightbulb } from 'lucide-react';
import CapabilityCard from './CapabilityCard';

const CAPABILITIES = [
{
  icon: Layers,
  title: 'Product Management',
  items: [
  'Shape product concepts, service experiences, and AI-enabled capabilities',
  'Product prioritization, validation, and decision-making',
  'Build customer-centered foundations for scalable product development']

},
{
  icon: Target,
  title: 'Strategic Customer Insights',
  items: [
  'Translate customer behavior and feedback into strategic direction',
  'Connect customer understanding directly to roadmap and investment decisions',
  'Identify unmet needs, friction points, and growth opportunities']

},
{
  icon: BarChart3,
  title: 'Customer Satisfaction and Loyalty',
  items: [
  'Measuring customer experience and customer touchpoints experience',
  'Connect customer experience to business outcomes',
  'Quantify the impact of customer experience on business performance']

},
{
  icon: Lightbulb,
  title: 'Innovation & Future Opportunities',
  items: [
  'Conduct behavioral, market, and trend research',
  'Explore AI capabilities and emerging customer expectations',
  'Support future-focused product and strategic initiatives']

}];


export default function WhatIDoSection() {
  return (
    <section className="py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div>
          <span className="mono-label text-muted-foreground mb-4 block">What I Do</span>
          <h2 className="font-semibold -fullheader normal-case text-xl mb-16 lg:text-xl max-w-4xl">I use customer data, research, and behavioral insights to drive product decisions, experience improvements, and measurable business impact. By connecting customer insights, journey maps, market research, and measurement systems, I create clearer direction, stronger alignment, and more informed decision-making.

          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {CAPABILITIES.map((cap, i) =>
            <CapabilityCard key={cap.title} {...cap} index={i} />
            )}
          </div>
        </div>
      </div>
    </section>);

}
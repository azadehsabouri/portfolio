import React from 'react';
import { motion } from 'framer-motion';
import { Map, Users, TrendingUp, FileText, Cpu, BarChart2 } from 'lucide-react';

const ASSET_TYPES = [
{ icon: Map, label: 'Customer Journey Maps', description: 'End-to-end experience visualizations across touchpoints' },
{ icon: Users, label: 'Behavioral Archetypes', description: 'Research-driven customer segments and behavior patterns' },
{ icon: TrendingUp, label: 'UX Multiplier Frameworks', description: 'Quantified experience-to-business impact models' },
{ icon: FileText, label: 'Trend Reports', description: 'Multi-country behavioral and market research outputs' },
{ icon: Cpu, label: 'AI Opportunity Mapping', description: 'Identified AI capability areas with measurable potential' },
{ icon: BarChart2, label: 'Strategy Diagrams', description: 'Visual frameworks connecting insights to decisions' }];


export default function VisualAssetsSection() {
  return (
    <section className="py-6 lg:py-8">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div>
          <span className="mono-label text-muted-foreground mb-4 block">Visual Frameworks & Assets</span>
          <h2 className="text-3xl lg:text-4xl font-semibold tracking-tight-header mb-4 max-w-2xl">
            Deliverables that bridge strategy and execution
          </h2>
          <p className="text-muted-foreground mb-12 max-w-xl">
            A selection of framework types and visual outputs produced across projects. Available as detailed case studies upon request.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {ASSET_TYPES.map((asset, i) =>
            <motion.div
              key={asset.label}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.06 }}
              className="group relative bg-secondary/20 border border-border/40 rounded-xl p-6 hover:border-primary/20 transition-colors">
              
                <div className="w-9 h-9 rounded-lg bg-primary/5 flex items-center justify-center mb-4 group-hover:bg-primary/10 transition-colors">
                  <asset.icon className="w-4.5 h-4.5 text-primary/70" />
                </div>
                <h3 className="text-sm font-semibold mb-1.5">{asset.label}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">{asset.description}</p>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </section>);

}
import React from 'react';
import { motion } from 'framer-motion';

const ROW_ONE = [
  'Business minded',
  'Analytical thinking',
  'System building',
  'Efficiency and optimization',
  'Visionary and practical',
];

const ROW_TWO = [
  'Product design and development',
  'Customer experience',
  'User research operations',
  'Customer-centric innovation',
];


export default function StrengthsSection() {
  return (
    <section className="py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <span className="mono-label text-muted-foreground mb-3 block">Core Strengths</span>
        <div className="flex flex-col gap-2">
          <div className="flex flex-wrap gap-2">
            {ROW_ONE.map((s, i) =>
              <motion.span
                key={s}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.25, delay: i * 0.04 }}
                className="inline-flex items-center px-3 py-1.5 text-xs border border-border/60 rounded-full text-muted-foreground bg-secondary/20">
                {s}
              </motion.span>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {ROW_TWO.map((s, i) =>
              <motion.span
                key={s}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.25, delay: i * 0.04 + 0.2 }}
                className="inline-flex items-center px-3 py-1.5 text-xs border border-primary/20 rounded-full text-foreground/70 bg-primary/[0.03]">
                {s}
              </motion.span>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
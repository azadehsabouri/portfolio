import React from 'react';
import { motion } from 'framer-motion';

const ROW_ONE = [
  'Business minded',
  'Analytical thinking',
  'System building',
  'Efficiency and optimization',
  'Visionary and practical',
];

const ROW_TWO = [
  'Product design and development',
  'Customer experience',
  'User research operations',
  'Customer-centric innovation',
];

export default function AboutSection() {
  return (
    <section id="about" className="py-16 lg:py-24">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <span className="mono-label text-muted-foreground mb-8 block">Who I Am</span>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
          {/* Bio text — left, larger */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-7 space-y-5 text-muted-foreground leading-relaxed text-[15px]">
            <p>
              I work at the intersection of customer understanding, product development,
              experience strategy, and innovation. My work combines research, operational
              thinking, and measurable execution to help teams build more relevant products,
              services, and future capabilities.
            </p>
            <p>
              I'm comfortable moving between strategy and implementation, working across
              leadership, product, design, engineering, and marketing to align decisions
              around evidence instead of assumptions.
            </p>
          </motion.div>

          {/* Core Strengths — right column */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="lg:col-span-5">
            <span className="mono-label text-muted-foreground mb-4 block">Core Strengths</span>
            <div className="flex flex-col gap-2">
              <div className="flex flex-wrap gap-2">
                {ROW_ONE.map((s, i) => (
                  <motion.span
                    key={s}
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.25, delay: i * 0.04 }}
                    className="inline-flex items-center px-3 py-1.5 text-xs border border-border/60 rounded-full text-muted-foreground bg-secondary/20">
                    {s}
                  </motion.span>
                ))}
              </div>
              <div className="flex flex-wrap gap-2">
                {ROW_TWO.map((s, i) => (
                  <motion.span
                    key={s}
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.25, delay: i * 0.04 + 0.2 }}
                    className="inline-flex items-center px-3 py-1.5 text-xs border border-primary/20 rounded-full text-foreground/70 bg-primary/[0.03]">
                    {s}
                  </motion.span>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>);

}
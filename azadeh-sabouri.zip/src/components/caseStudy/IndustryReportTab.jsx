import React, { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { FileText, ExternalLink, Upload, CheckCircle2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';

const DEFAULT_PDF_URL = 'https://media.base44.com/files/public/6a16b827a2fdd9691cb4372a/2877c2dac_Thestateofindustrialautomation20251.pdf';

const QUICK_STATS = [
  { value: '2,174', label: 'Respondents' },
  { value: '8', label: 'European Countries' },
  { value: '5+', label: 'Industry Sectors' },
  { value: 'B2B', label: 'Research Method' },
];

const RESEARCH_TOPICS = [
  'Drivers behind automation investments',
  'Adoption barriers and implementation challenges',
  "AI's growing role in manufacturing",
  'Workforce perceptions around robotics',
  'Industry-specific automation trends',
  'Future expectations toward intelligent automation',
];

const MY_ROLE = [
  'Designing the research framework and survey strategy',
  'Developing questionnaire structure and insight hypotheses',
  'Coordinating international B2B research panels',
  'Managing data collection across multiple European markets',
  'Analyzing quantitative data and identifying patterns',
  'Synthesizing findings into strategic narratives',
  'Supporting marketing and thought leadership storytelling',
];

const SECTORS = ['Manufacturing', 'Automotive', 'Engineering', 'Healthcare', 'Retail'];
const COUNTRIES = ['Denmark', 'France', 'Germany', 'Italy', 'Poland', 'Spain', 'Sweden', 'United Kingdom'];

export default function IndustryReportTab() {
  const [pdfUrl, setPdfUrl] = useState(DEFAULT_PDF_URL);
  const [uploading, setUploading] = useState(false);
  const [uploaded, setUploaded] = useState(false);
  const fileInputRef = useRef(null);

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setPdfUrl(file_url);
    setUploading(false);
    setUploaded(true);
  };

  return (
    <div className="space-y-8">
      {/* Hero block */}
      <div className="rounded-xl border border-border/40 bg-secondary/10 overflow-hidden">
        <div className="p-6 lg:p-8">
          <span className="mono-label text-primary/60 mb-3 block">Industry Research Report · 2025</span>
          <h2 className="text-2xl lg:text-3xl font-semibold tracking-tight leading-tight mb-3">
            Turning industrial data into strategic insight for the future of automation
          </h2>
          <p className="text-[15px] text-muted-foreground leading-relaxed max-w-2xl">
            Led the research design, international survey execution, data analysis, and insight generation behind a large-scale European automation industry report used for thought leadership and strategic marketing at Universal Robots.
          </p>

          <a
            href={pdfUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 mt-5 px-4 py-2.5 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors"
          >
            <FileText className="w-4 h-4" />
            View Full Report
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* Quick stats */}
      <div>
        <span className="mono-label text-muted-foreground mb-4 block">Quick Stats</span>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {QUICK_STATS.map((s, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.06 }}
              className="p-4 rounded-xl border border-border/40 bg-background text-center"
            >
              <div className="font-mono text-2xl font-bold text-foreground">{s.value}</div>
              <div className="text-xs text-muted-foreground mt-1">{s.label}</div>
            </motion.div>
          ))}
        </div>

        {/* Countries + Sectors strip */}
        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="p-4 rounded-xl border border-border/40 bg-background">
            <p className="mono-label text-muted-foreground mb-2 block">Countries</p>
            <div className="flex flex-wrap gap-1.5">
              {COUNTRIES.map((c, i) => (
                <span key={i} className="text-[11px] px-2 py-1 rounded-full bg-secondary/60 text-muted-foreground">{c}</span>
              ))}
            </div>
          </div>
          <div className="p-4 rounded-xl border border-border/40 bg-background">
            <p className="mono-label text-muted-foreground mb-2 block">Sectors</p>
            <div className="flex flex-wrap gap-1.5">
              {SECTORS.map((s, i) => (
                <span key={i} className="text-[11px] px-2 py-1 rounded-full bg-primary/10 text-primary/80">{s}</span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Two-col: About + My Role */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* About the project */}
        <div className="p-5 rounded-xl border border-border/40 bg-background space-y-4">
          <span className="mono-label text-muted-foreground block">About the Project</span>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Universal Robots wanted to better understand how European businesses are approaching industrial automation, AI adoption, workforce transformation, and collaborative robotics.
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed">
            The goal was to generate credible industry insights that could support thought leadership, strategic marketing, and market positioning across Europe.
          </p>
          <div>
            <p className="mono-label text-muted-foreground mb-2 block">Research Explored</p>
            <ul className="space-y-1.5">
              {RESEARCH_TOPICS.map((t, i) => (
                <li key={i} className="text-sm text-muted-foreground flex gap-2">
                  <span className="w-1 h-1 rounded-full bg-primary/40 mt-2 flex-shrink-0" />
                  {t}
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* My role */}
        <div className="p-5 rounded-xl border border-border/40 bg-primary/5 space-y-4">
          <span className="mono-label text-primary/60 block">My Role · Research &amp; Insight Leadership</span>
          <p className="text-sm text-muted-foreground leading-relaxed">
            I contributed to the end-to-end development of the research initiative, including:
          </p>
          <ul className="space-y-2">
            {MY_ROLE.map((r, i) => (
              <li key={i} className="text-sm text-foreground/80 flex gap-2">
                <span className="w-1 h-1 rounded-full bg-primary mt-2 flex-shrink-0" />
                {r}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Report link footer */}
      <div className="flex items-center justify-between p-4 rounded-xl border border-border/40 bg-secondary/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <FileText className="w-5 h-5 text-primary" />
          </div>
          <div>
            <p className="text-sm font-medium text-foreground">State of Industrial Automation Report 2025</p>
            <p className="text-xs text-muted-foreground">Originally published October 2025 · Updated April 2026 · Universal Robots</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <a
            href={pdfUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-xs text-primary font-medium hover:underline"
          >
            Open PDF <ExternalLink className="w-3 h-3" />
          </a>
          <input ref={fileInputRef} type="file" accept=".pdf" className="hidden" onChange={handleUpload} />
          <button
            onClick={() => fileInputRef.current.click()}
            disabled={uploading}
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground border border-border/50 hover:border-primary/30 px-3 py-1.5 rounded-lg transition-colors"
          >
            {uploaded ? <CheckCircle2 className="w-3 h-3 text-green-500" /> : <Upload className="w-3 h-3" />}
            {uploading ? 'Uploading…' : uploaded ? 'Replaced' : 'Replace PDF'}
          </button>
        </div>
      </div>
    </div>
  );
}
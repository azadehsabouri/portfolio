import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const ARCHETYPES = [
  {
    id: 'sp',
    code: 'SP',
    color: 'bg-rose-50 border-rose-200',
    accentBg: 'bg-rose-400',
    accentText: 'text-rose-700',
    tagBg: 'bg-rose-100 text-rose-700',
    characteristics: [
      'Always on the move — juggles multiple responsibilities simultaneously',
      'Relies heavily on mobile and quick-access tools',
      'Needs fast answers without deep technical knowledge',
      'Driven by efficiency and keeping things moving',
      'Prefers streamlined, intuitive interfaces over complex systems',
      'High urgency, low patience for friction or delays',
    ],
  },
  {
    id: 'em',
    code: 'EM',
    color: 'bg-amber-50 border-amber-200',
    accentBg: 'bg-amber-400',
    accentText: 'text-amber-700',
    tagBg: 'bg-amber-100 text-amber-700',
    characteristics: [
      'Deeply hands-on and technically immersed in their work',
      'Comfortable operating in complex or chaotic environments',
      'Learns through doing — experimentation over documentation',
      'Values direct access to technical data and controls',
      'High tolerance for complexity if it gives them control',
      'Motivated by mastery and solving difficult problems',
    ],
  },
  {
    id: 'ur',
    code: 'UR',
    color: 'bg-teal-50 border-teal-200',
    accentBg: 'bg-teal-500',
    accentText: 'text-teal-700',
    tagBg: 'bg-teal-100 text-teal-700',
    characteristics: [
      'Collaborative by nature — works across people and disciplines',
      'Translates between technical and non-technical stakeholders',
      'Focuses on knowledge sharing and alignment within teams',
      'Values clear communication and shared understanding',
      'Driven by getting everyone on the same page',
      'Needs tools that support coordination and visibility',
    ],
  },
  {
    id: 'ro',
    code: 'RO',
    color: 'bg-green-50 border-green-200',
    accentBg: 'bg-green-500',
    accentText: 'text-green-700',
    tagBg: 'bg-green-100 text-green-700',
    characteristics: [
      'Methodical and process-oriented in their approach',
      'Comfortable with hardware and physical systems',
      'Needs clear, step-by-step guidance when facing new situations',
      'Values reliability and predictability over advanced features',
      'Focused on getting the job done correctly the first time',
      'Low tolerance for ambiguity — prefers structured workflows',
    ],
  },
  {
    id: 'ma',
    code: 'MA',
    color: 'bg-purple-50 border-purple-200',
    accentBg: 'bg-purple-400',
    accentText: 'text-purple-700',
    tagBg: 'bg-purple-100 text-purple-700',
    characteristics: [
      'Operates at a managerial or decision-making level',
      'Needs oversight and summary views rather than operational detail',
      'Drives team alignment around goals and outcomes',
      'Focuses on business impact, performance, and results',
      'Values clear reporting and evidence to support decisions',
      'Motivated by efficiency gains and demonstrable outcomes',
    ],
  },
];

export default function BehavioralArchetypes() {
  const [selected, setSelected] = useState(ARCHETYPES[0].id);
  const archetype = ARCHETYPES.find(a => a.id === selected);

  return (
    <div>
      {/* Header */}
      <div className="mb-6">
        <span className="mono-label text-muted-foreground mb-2 block">Behavioral Archetypes</span>
        <p className="text-[15px] text-muted-foreground leading-relaxed max-w-2xl">
          Five behavioral archetypes developed from qualitative research across 71 participants. Used to create a shared company-wide understanding of who we design for — ensuring product, design, and strategy teams align on the same human realities when building solutions.
        </p>
      </div>

      {/* Dimensions */}
      <div className="mb-6 p-5 rounded-xl border border-border/40 bg-secondary/10">
        <p className="mono-label text-muted-foreground mb-3 block">Each Archetype Was Defined Across</p>
        <div className="flex flex-wrap gap-2">
          {['Needs', 'Challenges', 'Behaviors & Personality', 'Preferences', 'Moments of Truth', "Do's and Don'ts"].map((d) => (
            <span key={d} className="text-xs px-3 py-1.5 rounded-full bg-primary/8 border border-primary/15 text-primary/70 font-medium">{d}</span>
          ))}
        </div>
      </div>

      {/* Full image */}
      <div className="mb-8 rounded-xl overflow-hidden border border-border/40">
        <img
          src="https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/6aab39e9b_archetypes.png"
          alt="Behavioral Archetypes overview"
          className="w-full object-contain"
        />
      </div>

      {/* Archetype selector */}
      <div className="flex flex-wrap gap-2 mb-6">
        {ARCHETYPES.map((a) => (
          <button
            key={a.id}
            onClick={() => setSelected(a.id)}
            className={`px-4 py-2 rounded-lg border text-sm font-mono font-semibold transition-all duration-200
              ${selected === a.id
                ? `${a.accentBg} text-white border-transparent`
                : 'border-border/50 text-muted-foreground hover:text-foreground hover:border-primary/20 bg-secondary/20'
              }`}
          >
            {a.code}
          </button>
        ))}
      </div>

      {/* Detail card */}
      <AnimatePresence mode="wait">
        <motion.div
          key={selected}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.25 }}
        >
          <div className={`rounded-xl border-2 ${archetype.color} p-6 lg:p-8`}>
            <div className="flex items-center gap-3 mb-5">
              <div className={`${archetype.accentBg} text-white w-10 h-10 rounded-lg flex items-center justify-center font-mono font-bold text-sm`}>
                {archetype.code}
              </div>
              <span className="mono-label text-muted-foreground">Archetype Characteristics</span>
            </div>

            <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {archetype.characteristics.map((c, i) => (
                <li key={i} className="flex gap-3 items-start">
                  <span className={`mt-1.5 w-1.5 h-1.5 rounded-full flex-shrink-0 ${archetype.accentBg}`} />
                  <span className="text-[15px] text-muted-foreground leading-relaxed">{c}</span>
                </li>
              ))}
            </ul>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Research strip */}
      <div className="mt-8 p-5 rounded-xl border border-border/40 bg-secondary/10">
        <p className="mono-label text-muted-foreground mb-3 block">Research Foundation</p>
        <div className="flex flex-wrap gap-6 text-sm text-muted-foreground">
          <span><span className="font-mono font-semibold text-foreground">71</span> research participants</span>
          <span><span className="font-mono font-semibold text-foreground">5</span> behavioral archetypes</span>
          <span><span className="font-mono font-semibold text-foreground">Multi-country</span> scope</span>
          <span><span className="font-mono font-semibold text-foreground">Company-wide</span> alignment tool</span>
        </div>
      </div>
    </div>
  );
}
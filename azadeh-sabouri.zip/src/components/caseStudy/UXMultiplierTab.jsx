import React from 'react';
import { motion } from 'framer-motion';

const MY_CONTRIBUTIONS = [
  'Designing the research structure and measurement approach',
  'Conducting longitudinal customer experience research year by year',
  'Monitoring experience quality across customer touchpoints',
  'Connecting customer satisfaction data with behavioral and business indicators',
  'Developing the UX Multiplier formula and insight model',
  'Communicating findings to leadership and cross-functional teams',
  'Integrating the framework into business KPI and strategic decision-making discussions',
];

const OUTCOMES = [
  'Strategic prioritization',
  'KPI discussions',
  'Customer experience improvements',
  'Product and service decisions',
  'Cross-functional alignment around customer impact',
];

const INSIGHTS = [
  { label: 'High-impact touchpoints', desc: 'Identify which moments in the journey most strongly influence repeat purchase.' },
  { label: 'Experience gaps', desc: 'Reveal gaps with measurable business consequences.' },
  { label: 'Strategic opportunities', desc: 'Surface improvement areas with highest return on investment.' },
  { label: 'Investment prioritization', desc: 'Rank initiatives by business value, not assumption.' },
];

export default function UXMultiplierTab() {
  return (
    <div className="space-y-8">

      {/* Hero */}
      <div className="rounded-xl border border-border/40 bg-secondary/10 p-6 lg:p-8">
        <span className="mono-label text-primary/60 mb-3 block">CX Measurement Framework</span>
        <h2 className="text-2xl lg:text-3xl font-semibold tracking-tight leading-tight mb-3">
          UX Multiplier
        </h2>
        <p className="text-[15px] text-muted-foreground leading-relaxed max-w-2xl">
          Measuring the Business Impact of Customer Experience
        </p>
        <p className="text-[15px] text-muted-foreground leading-relaxed max-w-2xl mt-3">
          A data-driven model designed to understand how customer experience across different touchpoints influences business outcomes and long-term loyalty. The goal was not simply measuring satisfaction — it was understanding which customer experiences actually drive business value.
        </p>

      </div>

      {/* The Challenge */}
      <div className="p-5 rounded-xl border border-border/40 bg-background">
        <span className="mono-label text-muted-foreground mb-3 block">The Challenge</span>
        <p className="text-sm text-muted-foreground leading-relaxed mb-4">
          Customer experience was measured across many touchpoints, but there was limited visibility into:
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {[
            'Which touchpoints had the strongest business impact',
            'How customer experience influenced repeat purchase behavior',
            'Where improvements would create the highest value',
            'How to prioritize investments strategically',
          ].map((item, i) => (
            <div key={i} className="flex gap-2 text-sm text-foreground/80 p-3 rounded-lg bg-secondary/30">
              <span className="w-1 h-1 rounded-full bg-primary/50 mt-2 flex-shrink-0" />
              {item}
            </div>
          ))}
        </div>
      </div>

      {/* Formula */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="p-6 lg:p-8 rounded-xl border border-primary/20 bg-primary/5 text-center"
      >
        <span className="mono-label text-primary/60 mb-4 block">The Formula</span>
        <div className="inline-flex flex-col items-center gap-1">
          <div className="text-lg font-mono font-semibold text-primary">UX Multiplier</div>
          <div className="text-3xl font-mono font-bold text-foreground">=</div>
          <div className="flex flex-col items-center gap-1">
            <div className="text-base font-mono font-semibold text-foreground border-b border-foreground/40 pb-1 px-4">
              Business Outcome Impact
            </div>
            <div className="text-base font-mono font-semibold text-foreground pt-1 px-4">
              Customer Experience Improvement
            </div>
          </div>
        </div>
        <p className="text-sm text-muted-foreground mt-5 max-w-lg mx-auto leading-relaxed">
          The framework visualizes the relationship between customer satisfaction across touchpoints and the likelihood of repeat purchase and customer loyalty.
        </p>
      </motion.div>

      {/* Two-col: My Role + What it enables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="p-5 rounded-xl border border-border/40 bg-background space-y-4">
          <span className="mono-label text-muted-foreground block">My Contribution</span>
          <p className="text-sm text-muted-foreground leading-relaxed">
            I designed and led the customer research program behind the UX Multiplier framework over multiple years.
          </p>
          <ul className="space-y-2">
            {MY_CONTRIBUTIONS.map((c, i) => (
              <li key={i} className="text-sm text-foreground/80 flex gap-2">
                <span className="w-1 h-1 rounded-full bg-primary/40 mt-2 flex-shrink-0" />
                {c}
              </li>
            ))}
          </ul>
        </div>

        <div className="p-5 rounded-xl border border-border/40 bg-background space-y-4">
          <span className="mono-label text-muted-foreground block">What It Made Possible</span>
          <p className="text-sm text-muted-foreground leading-relaxed">
            The framework helped identify:
          </p>
          <div className="space-y-3">
            {INSIGHTS.map((item, i) => (
              <div key={i} className="p-3 rounded-lg bg-secondary/30">
                <p className="text-sm font-medium text-foreground">{item.label}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Outcome */}
      <div className="p-5 rounded-xl border border-border/40 bg-primary/5 space-y-4">
        <span className="mono-label text-primary/60 block">Outcome</span>
        <p className="text-sm text-muted-foreground leading-relaxed">
          The UX Multiplier became a framework used to support:
        </p>
        <div className="flex flex-wrap gap-2">
          {OUTCOMES.map((o, i) => (
            <span key={i} className="text-xs px-3 py-1.5 rounded-full bg-primary/10 text-primary/80 font-medium">{o}</span>
          ))}
        </div>
        <p className="text-sm text-muted-foreground leading-relaxed pt-2">
          Most importantly, it helped shift customer experience discussions from assumptions and opinions toward measurable business impact — a surprisingly rare achievement in corporate environments, where people can debate the color of a button for three months without once asking whether customers actually care.
        </p>
      </div>

    </div>
  );
}
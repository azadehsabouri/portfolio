import React, { useState } from 'react';
import { motion } from 'framer-motion';

export default function TimelineDiagram({ timeline }) {
  const [active, setActive] = useState(null);

  return (
    <div className="space-y-0">
      {/* Desktop: horizontal connector line */}
      <div className="hidden lg:block relative mb-12">
        <div className="absolute top-5 left-0 right-0 h-px bg-border" />
        <div className="flex justify-between relative">
          {timeline.map((item, i) => (
            <motion.button
              key={item.phase}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: i * 0.07 }}
              onClick={() => setActive(active === i ? null : i)}
              className="flex flex-col items-center gap-3 group flex-1 px-1"
              aria-expanded={active === i}
            >
              {/* Node */}
              <div
                className={`relative w-10 h-10 rounded-full border-2 flex items-center justify-center transition-all duration-200 z-10
                  ${active === i
                    ? 'bg-primary border-primary text-primary-foreground scale-110'
                    : 'bg-background border-border text-muted-foreground group-hover:border-primary/40 group-hover:text-foreground'
                  }`}
              >
                <span className="font-mono text-[10px] font-semibold">{item.phase}</span>
              </div>
              {/* Label */}
              <div className="text-center">
                <p className={`text-xs font-medium leading-tight ${active === i ? 'text-foreground' : 'text-muted-foreground group-hover:text-foreground'} transition-colors`}>
                  {item.label}
                </p>
                <p className="font-mono text-[9px] text-muted-foreground/60 mt-0.5">{item.duration}</p>
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Detail panel (desktop) */}
      {active !== null && (
        <motion.div
          key={active}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -4 }}
          transition={{ duration: 0.3 }}
          className="hidden lg:block p-6 rounded-xl bg-secondary/30 border border-border/40 mb-6"
        >
          <div className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
              <span className="font-mono text-[10px] font-semibold text-primary-foreground">
                {timeline[active].phase}
              </span>
            </div>
            <div>
              <div className="flex items-center gap-3 mb-1.5">
                <h4 className="font-semibold text-foreground">{timeline[active].label}</h4>
                <span className="mono-label text-muted-foreground">{timeline[active].duration}</span>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {timeline[active].description}
              </p>
            </div>
          </div>
        </motion.div>
      )}

      {/* Mobile: vertical timeline */}
      <div className="lg:hidden space-y-0">
        {timeline.map((item, i) => (
          <motion.div
            key={item.phase}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4, delay: i * 0.06 }}
            className="relative flex gap-4 pb-6"
          >
            {/* Vertical line */}
            {i < timeline.length - 1 && (
              <div className="absolute left-5 top-10 bottom-0 w-px bg-border" />
            )}
            {/* Node */}
            <button
              onClick={() => setActive(active === i ? null : i)}
              className={`w-10 h-10 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all z-10
                ${active === i ? 'bg-primary border-primary text-primary-foreground' : 'bg-background border-border text-muted-foreground hover:border-primary/40'}`}
            >
              <span className="font-mono text-[10px] font-semibold">{item.phase}</span>
            </button>
            {/* Content */}
            <div className="pt-1.5 flex-1">
              <div className="flex items-center gap-2 mb-1">
                <p className="text-sm font-medium">{item.label}</p>
                <span className="font-mono text-[9px] text-muted-foreground/60">{item.duration}</span>
              </div>
              <motion.div
                initial={false}
                animate={{ height: active === i ? 'auto' : 0, opacity: active === i ? 1 : 0 }}
                className="overflow-hidden"
              >
                <p className="text-sm text-muted-foreground leading-relaxed pb-1">
                  {item.description}
                </p>
              </motion.div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
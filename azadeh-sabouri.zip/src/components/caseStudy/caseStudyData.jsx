export const CASE_STUDIES = [
  {
    id: 'polaris',
    title: 'Polaris',
    titleFull: 'Polaris: Strategic Insights Operating System',
    subtitle: 'Insight Infrastructure',
    summary:
      'Built a scalable insight ecosystem connecting customer research to strategy, product development, and innovation.',
    heroImage: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/d2506b723_generated_image.png',
    heroImageFit: 'cover',
    overview: `Polaris is a centralized customer insight operating system designed to transform fragmented research into a living, strategic asset. The system was built to eliminate the "insight gap": the chronic distance between what customers experience and what internal teams know and act on.

The core challenge: insights were produced but not retained, shared, or activated at scale. Polaris solved this by creating infrastructure that makes customer knowledge searchable, shareable, and directly connected to product and strategic decisions.`,
    challenge: 'Organizations collect customer feedback continuously, but most of it disappears into reports, emails, and slide decks. Insights were siloed by team, format, and timing. Product, design, and strategy teams were making decisions based on assumptions rather than evidence.',
    approach: 'Designed as an operating system, not a research repository. Built around three layers: Collection (standardized intake), Synthesis (pattern recognition, behavioral archetypes), and Activation (strategic recommendation frameworks, stakeholder-ready outputs).',
    leadershipRole: 'Led the initiative end-to-end at Universal Robots — from identifying the organizational gap, through system design and build, to driving internal adoption across teams. Owned the vision, the architecture, and the change management required to embed insight use into daily decision-making.',
    handsOnContribution: 'Personally designed the system architecture and three-layer framework. Conducted and led the underlying customer research. Built the insight repository, defined the taxonomy, created the behavioral archetypes, and developed the stakeholder-facing activation outputs. Drove adoption from 10 to 500+ internal users through direct communication and enablement.',
    productOutcomes: 'Polaris became the primary evidence base for product and strategy decisions at Universal Robots. Most major product directions, roadmap priorities, and strategic initiatives were grounded in data and insights from this system.',
    delivered: [
      'Centralized research repository',
      'Insight operations framework',
      'Behavioral archetypes',
      'Customer journey mapping',
      'Strategic recommendation frameworks',
      'Scalable research processes',
    ],
    impact: [
      'Scaled insight adoption from 10 to 500+ internal users',
      'Enabled data-informed product, service, and marketing decisions',
      'Supported thought leadership and strategic communication initiatives',
      'Consolidated 5,000+ customer insights across qualitative and quantitative research',
    ],
    metrics: [
      { value: '500+', label: 'Internal Users' },
      { value: '5,000+', label: 'Insights Consolidated' },
      { value: '10→500', label: 'Adoption Scale' },
      { value: '3', label: 'System Layers' },
    ],
    gallery: [
      {
        src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/717fa256e_screencapture-teradynecom-sharepoint-sites-Insight-SitePages-How-universal-Robots-listen-to-the-world-aspx-2025-09-09-13_18_531copy.png',
        caption: 'Polaris System Architecture: Node Network Visualization',
        description: 'The Polaris knowledge graph represents connections between 5,000+ insights across behavioral, attitudinal, and contextual research dimensions.',
      },
      {
        src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/cd5bcb7ae_generated_image.png',
        caption: 'Insight Network: Data Connection Model',
        description: 'Each node represents a customer insight cluster. Connections indicate strategic relevance across product, service, and marketing domains.',
      },
      {
        src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/4cebc2323_generated_71631eb9.png',
        caption: 'Behavioral Archetype Framework',
        description: 'Archetypes derived from qualitative synthesis across 200+ research sessions, segmented by behavior patterns and unmet need clusters.',
      },
    ],
    timeline: [
      { phase: '01', label: 'Discovery & Audit', duration: 'Q1', description: 'Audited existing research outputs, identified gaps in knowledge retention, mapped stakeholder information needs.' },
      { phase: '02', label: 'System Design', duration: 'Q2', description: 'Designed the three-layer operating system: Collection, Synthesis, and Activation. Defined taxonomy and metadata standards.' },
      { phase: '03', label: 'Repository Build', duration: 'Q2–Q3', description: 'Built the centralized research repository. Consolidated 5,000+ insights. Established intake and tagging workflows.' },
      { phase: '04', label: 'Archetype Development', duration: 'Q3', description: 'Synthesized behavioral archetypes from qualitative research. Built the customer understanding framework.' },
      { phase: '05', label: 'Activation & Scale', duration: 'Q4', description: 'Rolled out to 500+ internal users. Embedded insight workflows into product, design, and marketing processes.' },
      { phase: '06', label: 'Continuous Operations', duration: 'Ongoing', description: 'Established ongoing research operations, governance model, and quarterly insight updates.' },
    ],
    documents: [
      { title: 'Polaris System Overview', type: 'PDF', description: 'Executive summary of the full insight operating system, architecture, and adoption model.', placeholder: true },
      { title: 'Behavioral Archetypes Report', type: 'PDF', description: 'Customer segment definitions derived from 200+ qualitative research sessions.', placeholder: true },
      { title: 'Insight Operations Framework', type: 'PDF', description: 'Repeatable process for collecting, tagging, synthesizing, and activating customer insights.', placeholder: true },
    ],
  },
  {
    id: 'cx-measurement',
    title: 'CX Measurement',
    titleFull: 'Customer Experience Measurement System',
    subtitle: 'Experience Measurement',
    summary:
      'Built a measurable customer experience framework connecting UX, satisfaction, and business outcomes across 33+ customer touchpoints.',
    heroImage: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/93f3b9081_CustomerExperiencemetrics.png',
    heroImageFit: 'contain',
    overview: `The CX Measurement System was built to answer a fundamental strategic question: what is the measurable business value of improving customer experience? By mapping 33+ touchpoints across the customer journey and connecting them to satisfaction scores and repurchase data, the system created a direct line between experience quality and business performance.

The UX Multiplier model quantifies how experience improvements translate to commercial outcomes, enabling evidence-based investment decisions.`,
    challenge: 'Customer experience was treated as a qualitative concern, hard to measure and harder to defend to leadership. There was no consistent framework for tracking experience quality across touchpoints or connecting it to business KPIs.',
    approach: 'Developed a multi-layer measurement system combining NPS, CSAT, touchpoint scoring, and behavioral analytics. Built the UX Multiplier model to quantify the experience-to-repurchase relationship. Established benchmarks and tracking cadence.',
    leadershipRole: 'Led the full initiative at Universal Robots — from defining the measurement strategy and framework design, through implementation, to embedding it as a permanent organizational capability. Drove alignment across leadership and cross-functional teams.',
    handsOnContribution: 'Personally built the measurement framework, mapped all 33+ touchpoints, and developed the UX Multiplier model. Conducted year-on-year measurement cycles that generated the longitudinal data needed to quantify the relationship between experience quality and business outcomes.',
    productOutcomes: 'The UX Multiplier model emerged directly from multi-year measurement data, providing a quantified formula linking CX improvements to repurchase likelihood — giving leadership a commercially defensible case for experience investment.',
    delivered: [
      'UX Multiplier model',
      'Experience score tracking across 33+ touchpoints',
      'NPS & CSAT measurement systems',
      'Journey and touchpoint analytics',
      'Benchmarking frameworks',
    ],
    impact: [
      'Quantified the relationship between CX and repurchase likelihood',
      'Enabled evidence-based prioritization across teams',
      'Increased Service CSAT from 3.5 to 4.7',
    ],
    metrics: [
      { value: '33+', label: 'Touchpoints Mapped' },
      { value: '3.5→4.7', label: 'CSAT Improvement' },
      { value: 'UX×', label: 'Multiplier Model' },
      { value: '4', label: 'Measurement Layers' },
    ],
    gallery: [
      {
        src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/ca9d678ce_generated_88ed1530.png',
        caption: 'Experience Measurement Architecture',
        description: 'Layered measurement model connecting touchpoint scores to journey analytics, NPS, CSAT, and the UX Multiplier formula.',
      },
      {
        src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/0fbf65052_generated_image.png',
        caption: 'Touchpoint Data Layer Model',
        description: 'Structural representation of the 33+ touchpoint measurement framework, organized by journey stage and channel type.',
      },
    ],
    timeline: [
      { phase: '01', label: 'Touchpoint Mapping', duration: 'Month 1–2', description: 'Mapped the complete customer journey across 33+ touchpoints. Defined measurement priorities by impact and feasibility.' },
      { phase: '02', label: 'Framework Design', duration: 'Month 2–3', description: 'Designed the multi-layer measurement framework. Selected metrics: NPS, CSAT, touchpoint scores, behavioral indicators.' },
      { phase: '03', label: 'Baseline Measurement', duration: 'Month 3–4', description: 'Established baseline scores. Service CSAT baseline: 3.5. Identified highest-friction touchpoints.' },
      { phase: '04', label: 'UX Multiplier Model', duration: 'Month 4–5', description: 'Built the model quantifying the experience-to-repurchase relationship. Validated with historical business data.' },
      { phase: '05', label: 'Improvement Initiatives', duration: 'Month 5–9', description: 'Systematic improvement program targeting highest-impact touchpoints. Cross-functional execution with product and service teams.' },
      { phase: '06', label: 'CSAT 4.7 Achieved', duration: 'Month 9–12', description: 'Service CSAT increased from 3.5 to 4.7. System embedded as ongoing measurement infrastructure.' },
    ],
    documents: [
      { title: 'UX Multiplier Formula', type: 'PDF', description: 'Quantitative model connecting CX scores to repurchase likelihood and business revenue impact.', placeholder: true },
      { title: 'CX Measurement Framework', type: 'PDF', description: 'Complete framework for 33+ touchpoint measurement, scoring, and benchmarking.', placeholder: true },
    ],
  },
  {
    id: 'product-foundations',
    title: 'Product & Experience Design',
    titleFull: 'Product Design',
    subtitle: 'Product Development',
    summary:
      'Built foundations for software, service, and AI-enabled product experiences.',
    heroImage: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/e62d76d06_NextGenrobotsoftware.png',
    heroImageFit: 'contain',
    overview: `Product & Experience Foundations translates customer understanding into concrete product direction. This work sits at the intersection of research, strategy, and product development, taking insight outputs and transforming them into actionable product concepts, feature definitions, and AI capability roadmaps.

The work enabled 10+ software features within one year and established the experience architecture for next-generation robot software.`,
    challenge: 'Product teams had access to customer research but lacked a structured method for translating insights into prioritized product decisions. AI opportunities were identified informally without a framework for evaluating impact or feasibility.',
    approach: 'Established a customer-to-product translation workflow. Built experience strategy frameworks connecting user needs to feature definitions. Conducted AI opportunity mapping to identify and prioritize AI-enabled capabilities with measurable business potential.',
    leadershipRole: 'Led the product and experience work at Universal Robots from insight to delivery — owning the translation from customer understanding into concrete product direction, and managing alignment across product, design, and engineering teams.',
    handsOnContribution: 'Personally built the experience strategy frameworks, defined feature concepts from customer evidence, and conducted the AI opportunity mapping. Embedded directly in the product development process to ensure customer evidence informed sprint prioritization throughout delivery.',
    productOutcomes: 'Contributed to 10+ software features shipped within one year, focusing on reducing deployment and optimization complexity for robot programmers and improving overall software usability. Established the experience foundation for Universal Robots\' next-generation robot software.',
    delivered: [
      'Product and experience strategy foundations',
      'Robot software experience concepts',
      'Service product concepts',
      'AI capability initiatives',
      'Experience strategy frameworks',
    ],
    impact: [
      'Contributed to the foundation of next-generation robot software',
      'Supported delivery of 10+ software features within one year',
      'Identified high-impact AI opportunity areas with measurable business potential',
      'Led internal AI capability building for customer insights and research operations',
    ],
    metrics: [
      { value: '10+', label: 'Features Delivered' },
      { value: '1 year', label: 'Delivery Timeline' },
      { value: 'AI', label: 'Opportunity Areas Mapped' },
      { value: 'Gen 2', label: 'Software Foundation' },
    ],
    gallery: [
      {
        src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/2c22c764a_generated_34ee9185.png',
        caption: 'Product Architecture Foundation',
        description: 'Structural model for the product experience framework, showing layered capability development from customer insight to feature definition.',
      },
      {
        src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/e434ec733_generated_image.png',
        caption: 'System Integration Model',
        description: 'Cross-functional product system showing how customer insights, experience strategy, and AI capabilities interconnect.',
      },
    ],
    timeline: [
      { phase: '01', label: 'Insight Translation', duration: 'Q1', description: 'Translated Polaris insights into structured product briefs. Identified top unmet needs by frequency and strategic impact.' },
      { phase: '02', label: 'Experience Strategy', duration: 'Q1–Q2', description: 'Developed experience strategy frameworks defining desired states across software, service, and AI dimensions.' },
      { phase: '03', label: 'Feature Definition', duration: 'Q2', description: 'Defined 10+ feature concepts from customer evidence. Prioritized against technical feasibility and business value.' },
      { phase: '04', label: 'AI Opportunity Mapping', duration: 'Q2–Q3', description: 'Conducted AI capability assessment. Identified high-impact areas where AI could reduce customer friction or create new value.' },
      { phase: '05', label: 'Software Development Support', duration: 'Q3–Q4', description: 'Embedded in product development process. Supported sprint prioritization with customer evidence.' },
      { phase: '06', label: '10+ Features Shipped', duration: 'Q4', description: '10+ software features delivered within one year. Robot software next-generation experience foundation established.' },
    ],
    documents: [
      { title: 'AI Opportunity Map', type: 'PDF', description: 'Prioritized map of AI capability areas with estimated business impact and feasibility ratings.', placeholder: true },
      { title: 'Experience Strategy Framework', type: 'PDF', description: 'Framework connecting customer needs to product concepts, service experiences, and AI capabilities.', placeholder: true },
    ],
  },
  {
    id: 'future-understanding',
    title: 'Future Understanding',
    titleFull: 'Future Customer Understanding',
    subtitle: 'Strategic Foresight',
    summary:
      'Led multi-country research and trend initiatives supporting long-term strategic direction.',
    heroImage: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/0b016bad8_TrendAnalysis.png',
    overview: `Future Customer Understanding is a strategic foresight program examining where customer expectations, behaviors, and needs are heading, before they become mainstream. By combining behavioral research, market trend analysis, and emerging technology mapping, this work provides organizations with a longer planning horizon.

Multi-country scope ensured that regional differences in customer expectations were captured and incorporated into global strategic direction.`,
    challenge: 'Strategic planning was anchored in current customer data, reactive rather than anticipatory. Organizations needed a forward-looking research capability to identify emerging needs, behavioral shifts, and AI-enabled expectations before competitors.',
    approach: 'Designed a foresight research program combining behavioral trend analysis, multi-country qualitative research, technology horizon scanning, and strategic scenario development. Outputs were designed for executive and board-level consumption.',
    leadershipRole: 'Led the foresight research initiative end-to-end at Universal Robots — from research design and multi-country field execution through synthesis, scenario development, and board-level presentation. Owned the full process and stakeholder communication.',
    handsOnContribution: 'Personally designed the research program, conducted and led multi-country qualitative research, synthesized findings with market and technology trends, and developed the strategic scenarios and foresight outputs delivered to executive and board audiences.',
    productOutcomes: 'Outputs directly influenced Universal Robots\' long-term company strategy, shaping the direction of AI product initiatives and informing strategic priorities around emerging customer expectations and market opportunities.',
    delivered: [
      'Trend reports across multiple markets',
      'Behavioral insight analysis',
      'Strategic foresight inputs',
      'Future customer need mapping',
      'Market research initiatives',
    ],
    impact: [
      'Influenced future strategic direction',
      'Supported AI-enabled product initiatives',
      'Aligned organizational priorities around emerging customer and market needs',
    ],
    metrics: [
      { value: 'Multi', label: 'Country Research Scope' },
      { value: '3–5yr', label: 'Strategic Horizon' },
      { value: 'AI', label: 'Enabled Initiatives' },
      { value: 'Board', label: 'Level Audience' },
    ],
    gallery: [
      {
        src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/944961fc8_generated_b2d822da.png',
        caption: 'Strategic Foresight Compass',
        description: 'Directional framework mapping emerging customer expectations, behavioral trends, and AI-enabled capability opportunities across a 3–5 year horizon.',
      },
      {
        src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/6e4f42243_generated_image.png',
        caption: 'Multi-Country Research Terrain',
        description: 'Spatial representation of multi-market research scope, showing regional variation in customer expectations and behavioral patterns.',
      },
    ],
    timeline: [
      { phase: '01', label: 'Research Design', duration: 'Month 1', description: 'Designed the multi-country foresight research program. Defined research questions around 3–5 year customer and market horizons.' },
      { phase: '02', label: 'Field Research', duration: 'Month 2–4', description: 'Conducted qualitative research across multiple countries. Collected behavioral observations, expectation mapping, and trend indicators.' },
      { phase: '03', label: 'Trend Analysis', duration: 'Month 4–5', description: 'Synthesized research with technology trends, market signals, and behavioral pattern analysis. Identified convergence points.' },
      { phase: '04', label: 'Scenario Development', duration: 'Month 5–6', description: 'Developed strategic scenarios showing how customer expectations may evolve. Linked to AI and product capability opportunities.' },
      { phase: '05', label: 'Executive Reporting', duration: 'Month 6', description: 'Delivered board-level trend reports and strategic foresight inputs. Facilitated alignment workshops.' },
      { phase: '06', label: 'Strategic Integration', duration: 'Ongoing', description: 'Foresight outputs embedded into product roadmap and AI capability planning processes.' },
    ],
    documents: [
      { title: 'Future Customer Trends Report', type: 'PDF', description: 'Multi-country analysis of emerging customer behaviors, expectations, and unmet needs across a 3–5 year horizon.', placeholder: true },
      { title: 'AI Opportunity Foresight', type: 'PDF', description: 'Strategic mapping of AI-enabled capabilities aligned to future customer expectations.', placeholder: true },
    ],
  },
];
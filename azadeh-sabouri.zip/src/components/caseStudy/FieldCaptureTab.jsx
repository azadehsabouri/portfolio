import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const IMAGES = [
  {
    src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/3d72f2b76_unnamed1.png',
    caption: 'Problem Space: The four core friction points driving insight loss in the field',
  },
  {
    src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/efb50806b_unnamed2.png',
    caption: 'Illustrated pain points: time-consuming reporting, tedious tasks, sharing barriers, knowledge loss',
  },
  {
    src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/5e12a1cd5_unnamed3.png',
    caption: 'Concept storyboard: from customer visit to insight capture to Salesforce sync',
  },
  {
    src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/627a4ae0a_unnamed4.png',
    caption: 'Mobile-first prototype: Customer Visit Report interface with voice, photo, and submit',
  },
  {
    src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/efe1c322e_unnamed5.png',
    caption: 'Responsive design concept: phone, tablet, and desktop wireframes',
  },
  {
    src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/874975c04_unnamed6.png',
    caption: 'Refined wireframe: cross-device consistency across mobile, tablet, and laptop',
  },
];

const FEATURES = [
  { label: 'Voice-to-Text', description: 'Record a voice memo on the spot — AI transcribes it into structured, searchable text.' },
  { label: 'Photo & Video', description: 'Attach visuals directly from your phone without leaving the app.' },
  { label: 'Smart Tagging', description: 'Tag by customer, topic, visit type, or project in seconds.' },
  { label: 'Offline Mode', description: 'Capture in the field with no signal — syncs automatically when back online.' },
  { label: 'CRM Integration', description: 'Pushes directly into Salesforce and the Polaris insight platform — no copy-paste.' },
  { label: 'AI Auto-Summary', description: 'Highlights key points and detects sentiment (frustrated, excited, neutral) from the note.' },
  { label: 'Feedback Loop', description: 'Contributors see how their input was used in product or service decisions.' },
  { label: 'Smart Nudges', description: 'Calendar-aware prompts remind field teams to log a visit right after it happens.' },
];

const IMPACT = [
  { area: 'Customer Experience', value: 'Better follow-up, stronger trust, no repeated questions' },
  { area: 'Team Efficiency', value: 'Minutes to submit, not an hour of manual reporting' },
  { area: 'Insight Quality', value: 'Real-time, contextual feedback captured while fresh' },
  { area: 'Sales & Support', value: 'Shared picture of what customers say and care about' },
  { area: 'Strategic Planning', value: 'Trends surface earlier and more visibly across the org' },
];

export default function FieldCaptureTab() {
  const [activeImage, setActiveImage] = useState(null);

  return (
    <div className="space-y-10">

      {/* Hero */}
      <div className="rounded-xl border border-border/40 bg-secondary/10 p-6 lg:p-8">
        <span className="mono-label text-primary/60 mb-3 block">AI-Powered Product · Internal Tool</span>
        <h2 className="text-2xl lg:text-3xl font-semibold tracking-tight leading-tight mb-3">
          AI-Empowered Field Visit Tool
        </h2>
        <p className="text-[15px] text-muted-foreground leading-relaxed max-w-2xl">
          A product initiative to eliminate the insight gap between field visits and organizational knowledge. Designed for Sales, Service, and Business Partners, this tool makes capturing and communicating customer insights as fast and frictionless as a voice memo — while feeding directly into CRM and insight systems.
        </p>
      </div>

      {/* Demo Video */}
      <div>
        <span className="mono-label text-muted-foreground mb-3 block">Product Demo</span>
        <div className="rounded-xl overflow-hidden border border-border/40 bg-black">
          <video
            src="https://media.base44.com/videos/public/6a16b827a2fdd9691cb4372a/fef8bb989_SmartVisitapp.mov"
            controls
            className="w-full max-h-[520px]"
            playsInline
          />
        </div>
      </div>

      {/* My Role */}
      <div className="p-5 rounded-xl border border-primary/20 bg-primary/5 space-y-3">
        <span className="mono-label text-primary/60 block">My Role</span>
        <p className="text-sm text-muted-foreground leading-relaxed">
          I led this initiative from concept to stakeholder buy-in. My work spanned building the business case, convincing stakeholders to invest, leading the product design, and collaborating internally to develop the use case and implementation plan.
        </p>
        <div className="flex flex-wrap gap-2 pt-1">
          {['Business Case Lead', 'Stakeholder Alignment', 'Product Design', 'Use Case Development', 'Internal Collaboration'].map((r, i) => (
            <span key={i} className="text-[11px] px-2.5 py-1 rounded-full bg-primary/10 text-primary border border-primary/20">{r}</span>
          ))}
        </div>
      </div>

      {/* The Problem */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="p-5 rounded-xl border border-border/40 bg-background space-y-4">
          <span className="mono-label text-muted-foreground block">The Problem</span>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Every time someone visits a customer — whether from Sales, Support, R&D, or Marketing — they see things, hear things, and get a feel for what's really going on. But after the visit, nobody wants to sit down and write a report, attach files, and log everything manually.
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed">
            It takes time, it's tedious, and in most cases it doesn't happen at all. So the knowledge is lost. Customer history ends up full of gaps, teams repeat the same questions, and decisions get made on assumptions instead of evidence.
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            {['Time-consuming', 'Tedious task', 'Not easy to share', 'Losing knowledge'].map((t, i) => (
              <span key={i} className="text-[11px] px-2.5 py-1 rounded-full bg-destructive/10 text-destructive/80 border border-destructive/20">{t}</span>
            ))}
          </div>
        </div>

        <div className="p-5 rounded-xl border border-border/40 bg-primary/5 space-y-4">
          <span className="mono-label text-primary/60 block">The Vision</span>
          <p className="text-sm text-muted-foreground leading-relaxed">
            A tool that works on any device. Talk, snap a photo, jot a quick note — and be done in minutes. No long forms. No copy-pasting into reports. Just useful information, shared instantly with the people who need it, directly in Salesforce and the insight platform.
          </p>
          <ul className="space-y-1.5 mt-2">
            {['Nothing gets lost', 'Teams act faster on field signals', 'Stop asking the customer the same questions twice', 'Build a living customer knowledge base'].map((v, i) => (
              <li key={i} className="text-sm text-foreground/80 flex gap-2">
                <span className="w-1 h-1 rounded-full bg-primary mt-2 flex-shrink-0" />
                {v}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Visual Gallery */}
      <div>
        <span className="mono-label text-muted-foreground mb-4 block">Concept Visuals</span>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {IMAGES.map((img, i) => (
            <motion.div
              key={i}
              whileHover={{ scale: 1.02 }}
              className="cursor-pointer rounded-xl overflow-hidden border border-border/40 bg-white group"
              onClick={() => setActiveImage(img)}
            >
              <img src={img.src} alt={img.caption} className="w-full h-44 object-cover object-top" />
              <div className="p-2">
                <p className="text-[10px] text-muted-foreground leading-tight line-clamp-2">{img.caption}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Lightbox */}
      <AnimatePresence>
        {activeImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-black/80 flex items-center justify-center p-4"
            onClick={() => setActiveImage(null)}
          >
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="max-w-3xl w-full"
              onClick={e => e.stopPropagation()}
            >
              <img src={activeImage.src} alt={activeImage.caption} className="w-full rounded-xl" />
              <p className="text-xs text-white/70 mt-3 text-center">{activeImage.caption}</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Features */}
      <div>
        <span className="mono-label text-muted-foreground mb-4 block">Core Capabilities</span>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {FEATURES.map((f, i) => (
            <div key={i} className="p-4 rounded-xl border border-border/40 bg-background flex gap-3">
              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-medium text-foreground">{f.label}</p>
                <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{f.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Business Impact */}
      <div>
        <span className="mono-label text-muted-foreground mb-4 block">Business Impact</span>
        <div className="rounded-xl border border-border/40 overflow-hidden">
          {IMPACT.map((row, i) => (
            <div key={i} className={`flex gap-4 px-5 py-3.5 text-sm ${i % 2 === 0 ? 'bg-secondary/10' : 'bg-background'}`}>
              <span className="font-medium text-foreground w-44 flex-shrink-0">{row.area}</span>
              <span className="text-muted-foreground">{row.value}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Next steps */}
      <div className="p-5 rounded-xl border border-border/40 bg-background">
        <span className="mono-label text-muted-foreground mb-3 block">Proposed Next Steps</span>
        <ol className="space-y-2">
          {[
            'Talk to key users — Sales, Support, and R&D — to understand what would actually help them.',
            'Review existing tools that could be extended (Salesforce Mobile, research platforms).',
            'Run a design sprint to co-create flows, templates, and capture patterns with users.',
            'Build and test a lightweight prototype with voice input, tagging, and CRM sync.',
            'Run a small pilot, track submission rates and downstream insight usage.',
            'Improve and scale — connect to the full Polaris insight pipeline.',
          ].map((step, i) => (
            <li key={i} className="text-sm text-muted-foreground flex gap-3">
              <span className="font-mono text-primary/60 text-xs mt-0.5 flex-shrink-0">{String(i + 1).padStart(2, '0')}</span>
              {step}
            </li>
          ))}
        </ol>
      </div>

    </div>
  );
}
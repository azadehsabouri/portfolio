import React, { useState } from 'react';
import { FileText, Download, ExternalLink, Lock } from 'lucide-react';
import { motion } from 'framer-motion';

export default function DocumentViewer({ documents }) {
  const [requested, setRequested] = useState({});

  const handleRequest = (i) => {
    setRequested(prev => ({ ...prev, [i]: true }));
  };

  return (
    <div className="space-y-3">
      {documents.map((doc, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: i * 0.08 }}
          className="flex items-center gap-4 p-5 rounded-xl border border-border/50 bg-secondary/10 hover:border-primary/20 transition-colors group"
        >
          {/* Icon */}
          <div className="w-10 h-10 rounded-lg bg-primary/5 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/10 transition-colors">
            <FileText className="w-5 h-5 text-primary/60" />
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <p className="text-sm font-medium truncate">{doc.title}</p>
              <span className="font-mono text-[10px] px-1.5 py-0.5 bg-secondary rounded text-muted-foreground flex-shrink-0">
                {doc.type}
              </span>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">{doc.description}</p>
          </div>

          {/* Action */}
          {doc.placeholder ? (
            <div>
              {requested[i] ? (
                <span className="text-xs text-primary font-medium whitespace-nowrap">Requested ✓</span>
              ) : (
                <button
                  onClick={() => handleRequest(i)}
                  className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground border border-border/50 hover:border-primary/30 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap min-h-[44px]"
                >
                  <Lock className="w-3 h-3" />
                  Request Access
                </button>
              )}
            </div>
          ) : (
            <a
              href={doc.url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-xs font-medium text-primary hover:text-primary/80 border border-primary/20 hover:border-primary/40 px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap min-h-[44px]"
            >
              <Download className="w-3 h-3" />
              Download
            </a>
          )}
        </motion.div>
      ))}

      <p className="text-xs text-muted-foreground/60 mt-4 font-mono">
        * Documents available upon request for qualified professional inquiries.
      </p>
    </div>
  );
}
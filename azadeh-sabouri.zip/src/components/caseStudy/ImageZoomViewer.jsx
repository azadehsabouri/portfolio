import React, { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ZoomIn, ZoomOut, X, ChevronLeft, ChevronRight } from 'lucide-react';

export default function ImageZoomViewer({ images, initialIndex = 0, onClose }) {
  const [current, setCurrent] = useState(initialIndex);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef(null);
  const imgRef = useRef(null);

  const img = images[current];

  const zoomIn = () => setZoom(z => Math.min(z + 0.5, 4));
  const zoomOut = () => {
    const newZ = Math.max(zoom - 0.5, 1);
    setZoom(newZ);
    if (newZ === 1) setPan({ x: 0, y: 0 });
  };
  const resetZoom = () => { setZoom(1); setPan({ x: 0, y: 0 }); };

  const navigate = (dir) => {
    setCurrent(i => (i + dir + images.length) % images.length);
    resetZoom();
  };

  const onMouseDown = useCallback((e) => {
    if (zoom <= 1) return;
    setIsDragging(true);
    dragStart.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
  }, [zoom, pan]);

  const onMouseMove = useCallback((e) => {
    if (!isDragging || !dragStart.current) return;
    setPan({ x: e.clientX - dragStart.current.x, y: e.clientY - dragStart.current.y });
  }, [isDragging]);

  const onMouseUp = useCallback(() => { setIsDragging(false); }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[200] bg-black/95 flex flex-col"
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      onMouseLeave={onMouseUp}
    >
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
        <div>
          <p className="font-mono text-xs text-white/40 tracking-widest uppercase mb-0.5">
            {current + 1} / {images.length}
          </p>
          <p className="text-sm font-medium text-white/80">{img.caption}</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={zoomOut}
            disabled={zoom <= 1}
            className="w-9 h-9 flex items-center justify-center rounded-lg border border-white/10 text-white/60 hover:text-white hover:border-white/30 disabled:opacity-30 transition-colors"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={resetZoom}
            className="px-3 h-9 font-mono text-xs text-white/60 hover:text-white border border-white/10 hover:border-white/30 rounded-lg transition-colors"
          >
            {Math.round(zoom * 100)}%
          </button>
          <button
            onClick={zoomIn}
            disabled={zoom >= 4}
            className="w-9 h-9 flex items-center justify-center rounded-lg border border-white/10 text-white/60 hover:text-white hover:border-white/30 disabled:opacity-30 transition-colors"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <div className="w-px h-6 bg-white/10 mx-1" />
          <button
            onClick={onClose}
            className="w-9 h-9 flex items-center justify-center rounded-lg border border-white/10 text-white/60 hover:text-white hover:border-white/30 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Image area */}
      <div
        className="flex-1 relative overflow-hidden flex items-center justify-center"
        style={{ cursor: zoom > 1 ? (isDragging ? 'grabbing' : 'grab') : 'default' }}
        onMouseDown={onMouseDown}
        onDoubleClick={() => zoom === 1 ? zoomIn() : resetZoom()}
      >
        <AnimatePresence mode="wait">
          <motion.img
            key={current}
            ref={imgRef}
            src={img.src}
            alt={img.caption}
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1, x: pan.x, y: pan.y }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            style={{ transform: `scale(${zoom}) translate(${pan.x / zoom}px, ${pan.y / zoom}px)`, maxHeight: '70vh', maxWidth: '90vw', objectFit: 'contain' }}
            className="select-none"
            draggable={false}
          />
        </AnimatePresence>

        {/* Nav arrows */}
        {images.length > 1 && (
          <>
            <button
              onClick={() => navigate(-1)}
              className="absolute left-4 w-11 h-11 flex items-center justify-center rounded-xl bg-white/5 hover:bg-white/15 border border-white/10 text-white/60 hover:text-white transition-all"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => navigate(1)}
              className="absolute right-4 w-11 h-11 flex items-center justify-center rounded-xl bg-white/5 hover:bg-white/15 border border-white/10 text-white/60 hover:text-white transition-all"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </>
        )}
      </div>

      {/* Caption */}
      <div className="px-6 py-5 border-t border-white/10">
        <p className="text-sm text-white/50 max-w-2xl mx-auto text-center leading-relaxed">
          {img.description}
        </p>
        <p className="text-white/20 text-xs text-center mt-2 font-mono">Double-click to zoom · Drag to pan</p>
      </div>

      {/* Thumbnails */}
      {images.length > 1 && (
        <div className="flex justify-center gap-2 pb-5">
          {images.map((img, i) => (
            <button
              key={i}
              onClick={() => { setCurrent(i); resetZoom(); }}
              className={`w-12 h-8 rounded overflow-hidden border-2 transition-colors ${i === current ? 'border-white/60' : 'border-white/10 opacity-40 hover:opacity-70'}`}
            >
              <img src={img.src} alt="" className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      )}
    </motion.div>
  );
}
import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import BehavioralArchetypes from '@/components/caseStudy/BehavioralArchetypes';
import CustomerJourneyTab from '@/components/caseStudy/CustomerJourneyTab';
import ImageZoomViewer from '@/components/caseStudy/ImageZoomViewer';
import IndustryReportTab from '@/components/caseStudy/IndustryReportTab';
import FieldCaptureTab from '@/components/caseStudy/FieldCaptureTab';
import UXMultiplierTab from '@/components/caseStudy/UXMultiplierTab';

export default function CaseStudyModal({ study, onClose, onPrev, onNext, initialTab }) {
  const scrollRef = useRef(null);
  const [activeTab, setActiveTab] = useState(initialTab || 'Overview');

  const tabs = study?.id === 'polaris'
    ? ['Overview', 'Customer Journey', 'Behavioral Archetypes', 'Industry Report']
    : study?.id === 'product-foundations'
    ? ['Overview', 'AI-Empowered Field Visit Tool']
    : study?.id === 'cx-measurement'
    ? ['Overview', 'UX Multiplier']
    : ['Overview'];

  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = ''; };
  }, []);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
    setActiveTab(initialTab || 'Overview');
  }, [study?.id]);

  useEffect(() => {
    const handler = (e) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') onPrev();
      if (e.key === 'ArrowRight') onNext();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose, onPrev, onNext]);

  if (!study) return null;

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.25 }}
        className="fixed inset-0 z-[100] bg-black/50 backdrop-blur-sm"
        onClick={onClose}
        aria-label="Close modal"
      />

      <motion.div
        initial={{ opacity: 0, y: '4%', scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: '3%', scale: 0.99 }}
        transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
        className="fixed inset-x-0 bottom-0 lg:inset-x-4 lg:top-4 lg:bottom-4 z-[110] bg-background rounded-t-2xl lg:rounded-2xl flex flex-col overflow-hidden max-w-6xl mx-auto shadow-2xl"
        onClick={e => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-label={study.titleFull}
      >
        {/* ── HEADER ── */}
        <div className="flex items-start justify-between gap-4 px-6 lg:px-10 pt-6 pb-4 border-b border-border/50 flex-shrink-0">
          <div className="min-w-0">
            <span className="mono-label text-primary/60 mb-1 block">{study.subtitle}</span>
            <h2 className="text-xl lg:text-2xl font-semibold tracking-tight text-foreground leading-tight">
              {study.titleFull}
            </h2>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <button onClick={onPrev} className="w-9 h-9 flex items-center justify-center rounded-lg border border-border/50 hover:border-primary/30 text-muted-foreground hover:text-foreground transition-colors" aria-label="Previous case study">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button onClick={onNext} className="w-9 h-9 flex items-center justify-center rounded-lg border border-border/50 hover:border-primary/30 text-muted-foreground hover:text-foreground transition-colors" aria-label="Next case study">
              <ChevronRight className="w-4 h-4" />
            </button>
            <div className="w-px h-5 bg-border mx-0.5" />
            <button onClick={onClose} className="w-9 h-9 flex items-center justify-center rounded-lg border border-border/50 hover:border-primary/30 text-muted-foreground hover:text-foreground transition-colors" aria-label="Close">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ── TABS (only shown when there are multiple) ── */}
        {tabs.length > 1 && (
          <div className="flex gap-0.5 px-6 lg:px-10 pt-3 pb-0 flex-shrink-0 border-b border-border/30">
            {tabs.map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-4 py-2 text-sm font-medium transition-colors rounded-t-lg relative min-h-[44px]
                  ${activeTab === tab ? 'text-foreground' : 'text-muted-foreground hover:text-foreground'}`}
              >
                {tab}
                {activeTab === tab && (
                  <motion.div layoutId="tab-indicator" className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary rounded-t" />
                )}
              </button>
            ))}
          </div>
        )}

        {/* ── CONTENT ── */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto px-6 lg:px-10 py-8">

          {activeTab === 'Overview' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
              <div className="lg:col-span-2 space-y-5">
                <div>
                  <span className="mono-label text-muted-foreground mb-2 block">Overview</span>
                  <div className="space-y-3">
                    {study.overview.split('\n\n').map((para, i) => (
                      <p key={i} className="text-[15px] text-muted-foreground leading-relaxed">{para}</p>
                    ))}
                  </div>
                </div>
                <div className="pt-4">
                  <span className="mono-label text-muted-foreground mb-2 block">Business Challenge</span>
                  <p className="text-[15px] text-muted-foreground leading-relaxed">{study.challenge}</p>
                </div>
                <div className="pt-4">
                  <span className="mono-label text-muted-foreground mb-2 block">Approach</span>
                  <p className="text-[15px] text-muted-foreground leading-relaxed">{study.approach}</p>
                </div>
                {study.leadershipRole && (
                  <div className="pt-4">
                    <span className="mono-label text-muted-foreground mb-2 block">Leadership Role</span>
                    <p className="text-[15px] text-muted-foreground leading-relaxed">{study.leadershipRole}</p>
                  </div>
                )}
                {study.handsOnContribution && (
                  <div className="pt-4">
                    <span className="mono-label text-muted-foreground mb-2 block">Hands-On Contribution</span>
                    <p className="text-[15px] text-muted-foreground leading-relaxed">{study.handsOnContribution}</p>
                  </div>
                )}
                {study.productOutcomes && (
                  <div className="pt-4">
                    <span className="mono-label text-muted-foreground mb-2 block">Product & Experience Outcomes</span>
                    <p className="text-[15px] text-muted-foreground leading-relaxed">{study.productOutcomes}</p>
                  </div>
                )}
              </div>

              <div className="space-y-6">
                <div>
                  <span className="mono-label text-muted-foreground mb-3 block">Key Metrics</span>
                  <div className="grid grid-cols-2 gap-2">
                    {study.metrics.map((m, i) => (
                      <div key={i} className="p-3 rounded-lg bg-secondary/30 border border-border/40">
                        <div className="font-mono text-lg font-semibold tracking-tight text-foreground">{m.value}</div>
                        <div className="text-[10px] text-muted-foreground mt-0.5 leading-tight">{m.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="mono-label text-muted-foreground mb-3 block">Delivered</span>
                  <ul className="space-y-1.5">
                    {study.delivered.map((d, i) => (
                      <li key={i} className="text-xs text-muted-foreground flex gap-2">
                        <span className="w-1 h-1 rounded-full bg-primary/30 mt-1.5 flex-shrink-0" />
                        {d}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <span className="mono-label text-muted-foreground mb-3 block">Impact</span>
                  <ul className="space-y-1.5">
                    {study.impact.map((d, i) => (
                      <li key={i} className="text-xs text-foreground/80 flex gap-2">
                        <span className="w-1 h-1 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                        {d}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'Behavioral Archetypes' && (
            <motion.div
              key="archetypes"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <BehavioralArchetypes />
            </motion.div>
          )}

          {activeTab === 'AI-Empowered Field Visit Tool' && (
            <motion.div
              key="field-capture"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <FieldCaptureTab />
            </motion.div>
          )}

          {activeTab === 'Industry Report' && (
            <motion.div
              key="industry-report"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <IndustryReportTab />
            </motion.div>
          )}

          {activeTab === 'UX Multiplier' && (
            <motion.div
              key="ux-multiplier"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <UXMultiplierTab />
            </motion.div>
          )}

          {activeTab === 'Customer Journey' && (
            <motion.div
              key="customer-journey"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <CustomerJourneyTab />
            </motion.div>
          )}

        </div>
      </motion.div>
    </>
  );
}
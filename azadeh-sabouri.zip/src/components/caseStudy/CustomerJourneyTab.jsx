import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ZoomIn } from 'lucide-react';
import ImageZoomViewer from '@/components/caseStudy/ImageZoomViewer';

const IMAGES = [
  {
    src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/87589035e_customerjourneyoveral.png',
    caption: 'Overall Customer Journey Map',
    description: 'The full-lifecycle journey model showing the before-purchase and after-purchase experience across all key phases: Trigger, Evaluate Need, Deploy, Play, Onboard, Transform, Guidance, and Advocacy.',
  },
  {
    src: 'https://media.base44.com/images/public/6a16b827a2fdd9691cb4372a/3d8ac7e35_customerjourneymap.png',
    caption: 'Detailed Journey Map — Built in UXPressia',
    description: 'A 11-phase detailed customer journey map covering Awareness through Scale & Grow, documenting user goals, touchpoints, experience curves, pain points, opportunities, and evidence at each stage.',
  },
];

const MY_ROLE = [
  'Defined the research strategy and methodology for journey mapping',
  'Conducted and analysed qualitative and quantitative customer research',
  'Built the end-to-end journey maps across customer segments',
  'Identified key pain points, opportunities, and experience gaps',
  'Defined the future-state CX strategy and improvement roadmap',
  'Communicated findings and aligned stakeholders on solutions',
];

export default function CustomerJourneyTab() {
  const [zoomIndex, setZoomIndex] = useState(null);

  return (
    <div>
      {zoomIndex !== null && (
        <ImageZoomViewer
          images={IMAGES}
          initialIndex={zoomIndex}
          onClose={() => setZoomIndex(null)}
        />
      )}

      {/* Intro */}
      <div className="mb-8">
        <span className="mono-label text-muted-foreground mb-2 block">Customer Journey Maps</span>
        <p className="text-[15px] text-muted-foreground leading-relaxed max-w-2xl">
          Customer journey mapping is a core tool within Polaris — a dynamic asset that communicates customers' pain points, processes, and needs based on data at each step of their journey with Universal Robots products and services.
        </p>
      </div>

      {/* My Role */}
      <div className="mb-10 p-5 rounded-xl border border-border/40 bg-secondary/10">
        <span className="mono-label text-muted-foreground mb-3 block">My Role</span>
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-y-2 gap-x-8">
          {MY_ROLE.map((item, i) => (
            <li key={i} className="text-sm text-muted-foreground flex gap-2">
              <span className="w-1 h-1 rounded-full bg-primary/40 mt-1.5 flex-shrink-0" />
              {item}
            </li>
          ))}
        </ul>
      </div>

      {/* Images */}
      <div className="space-y-6">
        <span className="mono-label text-muted-foreground block">Journey Map Visuals</span>
        {IMAGES.map((img, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: i * 0.1 }}
            className="rounded-xl border border-border/40 overflow-hidden bg-white group cursor-pointer"
            onClick={() => setZoomIndex(i)}
          >
            <div className="relative overflow-hidden">
              <img
                src={img.src}
                alt={img.caption}
                className="w-full object-contain max-h-[480px] group-hover:scale-[1.01] transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-200 flex items-center justify-center">
                <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-white/90 rounded-full p-3 shadow-lg">
                  <ZoomIn className="w-5 h-5 text-foreground" />
                </div>
              </div>
            </div>
            <div className="px-5 py-4 border-t border-border/30">
              <p className="text-sm font-medium text-foreground mb-1">{img.caption}</p>
              <p className="text-xs text-muted-foreground leading-relaxed">{img.description}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
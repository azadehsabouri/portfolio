import React from 'react';
import Navigation from '../components/portfolio/Navigation';
import HeroSection from '../components/portfolio/HeroSection';
import AboutSection from '../components/portfolio/AboutSection';
import ImpactDashboard from '../components/portfolio/ImpactDashboard';
import WhatIDoSection from '../components/portfolio/WhatIDoSection';
import WorkSection from '../components/portfolio/WorkSection';
import VisualAssetsSection from '../components/portfolio/VisualAssetsSection';
import ToolsSection from '../components/portfolio/ToolsSection';
import PhilosophySection from '../components/portfolio/PhilosophySection';
import CareerTimeline from '../components/portfolio/CareerTimeline';
import EducationSection from '../components/portfolio/EducationSection';
import ContactSection from '../components/portfolio/ContactSection';
import Footer from '../components/portfolio/Footer';

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground antialiased">
      <Navigation />
      <main>
        <HeroSection />
        <ImpactDashboard />
        <div className="bg-secondary/40">
          <WhatIDoSection />
        </div>
        <WorkSection />
        <div className="bg-secondary/40">
          <VisualAssetsSection />
        </div>
        <ToolsSection />
        <div className="bg-secondary/40">
          <AboutSection />
        </div>
        <div className="bg-secondary/40">
          <PhilosophySection />
        </div>
        <div className="bg-secondary/40">
          <CareerTimeline />
        </div>
        <EducationSection />
        <div className="bg-secondary/30">
          <ContactSection />
        </div>
      </main>
      <Footer />
    </div>
  );
}